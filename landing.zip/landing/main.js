/* Moralis init code */
// REPLACE THE BELOW SERVER_URL and APP_ID with your own
const serverUrl = "https://z4wbmcmm2ouz.usemoralis.com:2053/server";
const appId = "fISZ9690LUmJNPGW7IY0d3rnu32U5WCah1Pjt7HE";
let user = JSON.parse(localStorage.getItem(`Parse/${appId}/currentUser`));

formatETHAddress = function(s, size = 4) {;
  var first = s.slice(0, size + 1);
  var last = s.slice(-size);
  return first + "..." + last;
}

Moralis.start({ serverUrl, appId });

if (user) {
  user.get = (name) => user[name];
  setUser(user);
}

/* Authentication code */
async function login() {
  if (!user) {
    user = await Moralis.authenticate({
      signingMessage: "Sign in to Moon Robots"
    })
      .then(function (user) {
        console.log("logged in user:", user);
        setUser(user);
      })
      .catch(function (error) {
        console.log(error);
      });
  } else {
    setUser(user);
  }
}

function emptyIfUndefined(s) {
  if (s == 'undefined') {
    return '';
  };
  return s;
}

function checkDefined(s) {
  if (s == 'undefined') {
    return false;
  };
  return true;
}

function setUser(user) {
  setDataToLocalStorage(user);

  let ethAddress = user.get("ethAddress");
  document.getElementById("connect_metamask").textContent = formatETHAddress(`${ethAddress}`, 6);

  let presaleButton = document.getElementById("connect_metamask_presale");
  let presaleCaption = document.getElementById("register__caption");
  let edit = document.getElementById("edit");
  let submitButton = document.getElementById("submit_presale");

  if (presaleButton) {
    if (user.get("email_presale") !== undefined && user.get("email_presale") !== "") {
      presaleButton.textContent = "Registered";
      presaleCaption.innerHTML = "Your information";
      presaleButton.classList.add('registered');
      submitButton.textContent = "Update";
      edit.classList.add('active');
    } else {
      presaleButton.textContent = "Register now";
      presaleCaption.textContent = "Register your interest";
      submitButton.textContent = "Submit";
    }
  }

}

function setDataToLocalStorage(user) {
  localStorage.setItem("email_presale", user.get("email_presale"));
  localStorage.setItem("amount_presale", user.get("amount_presale"));
  localStorage.setItem("howUsed_presale", user.get("howUsed_presale"));
  localStorage.setItem("ethAddress", user.get("ethAddress"));
}

async function logOut() {
  await Moralis.User.logOut();
  document.getElementById("connect_metamask").textContent = "Connect Metamask";
}

window.addEventListener('load', function() {
  if (typeof web3 !== 'undefined') {
    console.log('web3 is enabled')
    if (web3.currentProvider.isMetaMask === true) {
      console.log('MetaMask is active')
    } else {
      console.log('MetaMask is not available')
    }
  } else {
    document.getElementById("connect_metamask").textContent = `Install Metamask`;
    document.getElementById("connect_metamask").addEventListener('click', function() {window.open(
      'https://metamask.io/download/',
      '_blank'
    );});
    document.getElementById("connect_metamask_presale").addEventListener('click', function() {window.open(
      'https://metamask.io/download/',
      '_blank'
    );});
    console.log('web3 is not found')
  }
})

function showPresaleData() {
  document.getElementById("email_presale").value = emptyIfUndefined(`${localStorage.getItem("email_presale")}`);
  document.getElementById("amount_presale").value = emptyIfUndefined(`${localStorage.getItem("amount_presale")}`);
  document.getElementById("howUsed_presale").value = emptyIfUndefined(`${localStorage.getItem("howUsed_presale")}`);
}

const presale_form = document.getElementById("register__form");
if (presale_form) { 
  presale_form.addEventListener("submit", function (event) {
    event.preventDefault();
    const { email_presale, amount_presale, howUsed_presale } = this.elements;
    Moralis.User.currentAsync().then(function (user) {

      user.set("email_presale", email_presale.value);
      user.set("amount_presale", amount_presale.value);
      user.set("howUsed_presale", howUsed_presale.value);

      localStorage.setItem("email_presale", email_presale.value);
      localStorage.setItem("amount_presale", amount_presale.value);
      localStorage.setItem("howUsed_presale", howUsed_presale.value);

      user.save().then(function (result) {
        $('.register').removeClass('active');
        setUser(user);
        // $.ajax({
        //   type: "POST",
        //   url: "./sendler.php",
        //   data: '55555',
        // });
      }).catch(error => {
        console.log(error);
      });;
    });
  });
}

document.getElementById("connect_metamask").onclick = login;

$('#connect_metamask_presale').on('click', function () {
  if (!JSON.parse(localStorage.getItem(`Parse/${appId}/currentUser`))) {
    return login();
  } else {
    showPresaleData();
    $('.register').addClass('active');
  }
});


$('#edit').on('click', function (event) {
  event.preventDefault();
  showPresaleData();
  $('.register').addClass('active');
});


$('#cancel_presale').on('click', function () {
  $('.register').removeClass('active');
});

window.ethereum.on('accountsChanged', async function (accounts) {
  console.log('accountsChanges',accounts);
  if (accounts.length > 0) {
    let user = await Moralis.authenticate({
      signingMessage: "Sign in to Moon Robots"
    })
      .then(function (user) {
        console.log("logged in user:", user);
        setUser(user);
      })
      .catch(function (error) {
        console.log(error);
      });
      document.getElementById("connect_metamask").textContent = formatETHAddress(`${accounts[0]}`, 6);
  } else {
    document.getElementById("connect_metamask").onclick = login;
    document.getElementById("connect_metamask").textContent = "Connect Metamask"
  }

});
