#!/bin/bash
# script to replace default config values with the ones from the env variables

# old sed commands to replace values in different files
sed -i "s|${API_URL_TO_REPLACE}|${API_URL}|g" src/additional.js
sed -i "s|${REACT_APP_URL_TO_REPLACE}|${REACT_APP_URL}|g" src/additional.js 
find . -regex ".*\.\(html\|js\)" -not -path "./node_modules/*" -exec sed -i "s|${LANDING_URL_TO_REPLACE}|${LANDING_URL}|g" {} +

# new sed commands to replace the values in a single file
sed -i "s|${REACT_APP_URL_TO_REPLACE}|${REACT_APP_URL}|g" src/config.js
sed -i "s|${API_URL_TO_REPLACE}|${API_URL}|g" src/config.js
sed -i "s|${LANDING_URL_TO_REPLACE}|${LANDING_URL}|g" src/config.js
sed -i "s|${CHAIN_TO_REPLACE}|${CHAIN}|g" src/config.js
sed -i "s|${ENV_TO_REPLACE}|${ENV}|g" src/config.js

echo Result config file:
cat src/config.js
