let submitButton = document.getElementById("submit_presale");
$("#hRegisterForm").val( submitButton.textContent );
$("#register__form button#submit_presale").click(function(e){
	$.post('mailer/send.php', $("#register__form").serialize()).fail(function(){console.log('error');});
});