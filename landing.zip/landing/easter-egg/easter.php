<?php

$id = $_GET['id'];
$type = $_GET['type'];


$types=array("1"=>"Gold","4"=>"Violet","2"=>"Pink","3"=>"Blue","5"=>"Stardust");
$eggs=array("1"=>"5","4"=>"10","2"=>"15","3"=>"20", "5"=>"3");
$images=array("1"=>"https://moonrobots.one/easter-egg/egg-gold.png","4"=>"https://moonrobots.one/easter-egg/egg-violet.png","2"=>"https://moonrobots.one/easter-egg/egg-pink.png","3"=>"https://moonrobots.one/easter-egg/egg-blue.png", "5"=>"https://moonrobots.one/easter-egg/egg-stardust.png");

// Set required headers
header('Content-Type: application/json; charset=utf-8');
$data = new \stdClass();
$data->tokenId = $id;
$data->type = $types[$type];
$data->name = sprintf('%s Easter egg', $types[$type]);
$data->description = 'Moon Robots Easter egg';
$data->image = $images[$type];

$traits = array();

if ($type == "5") {
	array_push($traits, (object)[
        'trait_type' => 'Eggs to combine',
        'value' => "3",
]);

array_push($traits, (object)[
        'trait_type' => 'Combine reward',
        'value' => '50 STARDUST',
]);

array_push($traits, (object)[
        'trait_type' => 'Note',
        'value' => sprintf('collect %s and combine into 50 STARDUST at https://moonrobots.one/my-tickets', $eggs[$type]),
]);

array_push($traits, (object)[
        'trait_type' => 'Airdrop',
        'value' => "check if you're eligible for an airdrop on https://moonrobots.one/my-tickets",
]);

$data->attributes = $traits;

header("Content-type: application/json; charset=utf-8");
echo stripslashes(json_encode($data));
} else {
	
array_push($traits, (object)[
        'trait_type' => 'Eggs to combine',
        'value' => $eggs[$type],
]);

array_push($traits, (object)[
        'trait_type' => 'Combine reward',
        'value' => '1x Free Mint',
]);

array_push($traits, (object)[
        'trait_type' => 'Note',
        'value' => sprintf('collect %s and combine into a free mint at https://moonrobots.one/my-tickets', $eggs[$type]),
]);

array_push($traits, (object)[
        'trait_type' => 'Airdrop',
        'value' => "check if you're eligible for an airdrop on https://moonrobots.one/my-tickets",
]);

$data->attributes = $traits;

header("Content-type: application/json; charset=utf-8");
echo stripslashes(json_encode($data));
}


?>